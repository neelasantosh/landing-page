import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';

function Header() {
  return (
    <Navbar collapseOnSelect expand="lg" fixed="top" bg="dark" variant="dark">
      <Container>
        <Navbar.Brand href="#testdemo">Test Demo</Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link href="#features">Test Link 1</Nav.Link>
            <Nav.Link href="#pricing">Test Link 2</Nav.Link>
          </Nav>
          <Nav>
            <Nav.Link href="#deets">Menu</Nav.Link>
            <Nav.Link eventKey={2} href="#memes">
              Test User Name
            </Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default Header;